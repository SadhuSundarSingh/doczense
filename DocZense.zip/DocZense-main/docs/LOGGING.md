# DocZense Logging Guide

DocZense includes comprehensive logging to help monitor application performance, debug issues, and track system behavior.

## Logging Features

- **Structured Logging**: Consistent format across all modules with timestamps, log levels, and context
- **File Rotation**: Automatic log file rotation to prevent disk space issues  
- **Separate Error Logs**: Critical errors are logged to separate files for easy monitoring
- **Performance Tracking**: Function execution times are automatically logged
- **Configurable Levels**: Easy adjustment of log verbosity via environment variables

## Log Levels

- **DEBUG**: Detailed diagnostic information (function entry/exit, parameters)
- **INFO**: General application flow and important events
- **WARNING**: Potential issues that don't break functionality  
- **ERROR**: Error conditions that may affect functionality
- **CRITICAL**: Severe errors that may cause application failure

## Configuration

Set environment variables to customize logging behavior:

```bash
# Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
export DOCZENSE_LOG_LEVEL=INFO

# Enable/disable console output (true/false)  
export DOCZENSE_CONSOLE_LOGGING=true

# Custom log directory (optional, defaults to ./logs)
export DOCZENSE_LOG_DIR=/path/to/custom/logs
```

## Log Files

Logs are written to the `logs/` directory by default:

- `doczense_YYYYMMDD.log` - Main application logs with rotation
- `doczense_errors_YYYYMMDD.log` - Error-level logs only
- Log files rotate when they reach 10MB, keeping 5 backup files

## Example Log Output

```
2025-08-02 14:30:15 | DocZenseApp | INFO | app.py:25 | __main__ | Starting DocZense application
2025-08-02 14:30:15 | DocumentChatbot | INFO | document_chatbot.py:31 | __init__ | Initializing DocumentChatbot
2025-08-02 14:30:16 | DocumentChatbot | DEBUG | document_chatbot.py:45 | process_pdf_files | ENTER process_pdf_files((['file.pdf'],), {})
2025-08-02 14:30:18 | DocumentChatbot | INFO | document_chatbot.py:52 | process_pdf_files | PDF extraction completed for file.pdf in 1.85 seconds
```

## Performance Monitoring

The logging system automatically tracks:

- Function execution times with the `@timed_function` decorator
- PDF processing duration
- URL extraction and validation times  
- LLM API call durations
- RAG pipeline performance

## Production Recommendations

For production deployments:

```bash
export DOCZENSE_LOG_LEVEL=WARNING
export DOCZENSE_CONSOLE_LOGGING=false  
export DOCZENSE_LOG_DIR=/var/log/doczense
```

This reduces log verbosity and disables console output for better performance.

## Monitoring Integration

The structured logging format makes it easy to integrate with log monitoring tools:

- **ELK Stack**: Elasticsearch, Logstash, Kibana
- **Splunk**: Enterprise log management  
- **Datadog**: Cloud monitoring and analytics
- **Grafana Loki**: Open-source log aggregation

## Troubleshooting

1. **No log files created**: Check file permissions in the log directory
2. **Log files not rotating**: Verify disk space and file permissions  
3. **Missing logs**: Check `DOCZENSE_LOG_LEVEL` environment variable
4. **Performance issues**: Set `DOCZENSE_LOG_LEVEL=WARNING` or higher
