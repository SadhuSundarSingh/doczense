"""
CRM Module
---------
This module provides functionality for answering questions about Zoho CRM.
It uses a pre-trained model to generate embeddings and find the most relevant information
in the CRM knowledge base to answer user queries.
"""

import json
import sys
import time
from typing import List, Dict, Tuple, Any

import numpy as np 

sys.path.append("/home/workspace/DocZense/src/api")

from api.system_prompt import SystemPrompt
from api.llm_inference import fetch_from_llm
from onnxruntime import InferenceSession
from sklearn.metrics.pairwise import cosine_similarity
from transformers import PreTrainedTokenizerBase, PreTrainedModel
from utils.logger import DocZenseLogger

class CRM:
    """
    Customer Relationship Management (CRM) class for handling CRM-related queries.
    
    This class provides methods to answer questions about Zoho CRM
    using semantic search and LLM-based response generation.
    """
    
    def __init__(self, tokenizer: PreTrainedTokenizerBase, session: InferenceSession):
        """
        Initialize the CRM handler with tokenizer and ONNX session.
        
        Args:
            tokenizer (PreTrainedTokenizerBase): The tokenizer to use for text processing
            session (InferenceSession): ONNX runtime session for the embedding model
        """
        self.logger = DocZenseLogger.get_logger("CRM")
        initialization_start_time = time.time()
        self.logger.info("🚀 Starting CRM initialization with knowledge base and embeddings")
        
        try:
            # Load CRM knowledge base sentences and embeddings
            sentences_start_time = time.time()
            self.logger.debug("Loading CRM knowledge base sentences from resources/zoho_crm_all_sentences.json")
            with open("resources/zoho_crm_all_sentences.json", "r") as f:
                f_str = f.read()
            sentences = json.loads(f_str)
            sentences_end_time = time.time()
            self.logger.info(f"✅ Loaded {len(sentences)} CRM knowledge base sentences in {sentences_end_time - sentences_start_time:.3f} seconds")
            
            embeddings_start_time = time.time()
            self.logger.debug("Loading CRM embeddings from resources/embeddings/zoho_crm_all_embeddings.npy")
            embeddings = np.load("resources/embeddings/zoho_crm_all_embeddings.npy")
            embeddings_end_time = time.time()
            self.logger.info(f"✅ Loaded embeddings with shape {embeddings.shape} in {embeddings_end_time - embeddings_start_time:.3f} seconds")

            # Store model components and data
            self.sentences = sentences
            self.embeddings = embeddings
            self.tokenizer = tokenizer
            self.session = session
            self.input_names = {inp.name for inp in self.session.get_inputs()}
            
            initialization_end_time = time.time()
            total_init_time = initialization_end_time - initialization_start_time
            self.logger.info(f"🎉 CRM initialization completed successfully in {total_init_time:.3f} seconds")
            
        except FileNotFoundError as e:
            self.logger.error(f"❌ Failed to load CRM resources: {str(e)}", exc_info=True)
            raise
        except Exception as e:
            self.logger.error(f"❌ Unexpected error during CRM initialization: {str(e)}", exc_info=True)
            raise        

    def get_query_rewrite_payload(self, user_query: str) -> List[Dict[str, str]]:
        """
        Create the payload for query rewriting.
        
        Args:
            user_query (str): The original user query
            
        Returns:
            List[Dict[str, str]]: Formatted payload for the LLM API call
        """
        payload_start_time = time.time()
        self.logger.debug(f"Creating query rewrite payload for: '{user_query[:100]}...'")
        
        payload_data = []
        user = {
            "role": "user",
            "content": f"Original Query: {user_query}\n\nPlease rewrite this query to make it clearer and more suitable for retrieving relevant information from a knowledge base."
        }
        payload_data.append(user)
        
        payload_end_time = time.time()
        self.logger.debug(f"Query rewrite payload created in {payload_end_time - payload_start_time:.4f} seconds")
        return payload_data

    def search_best_chunk(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Search for the most relevant chunks of information based on query similarity.
        
        Args:
            query (str): The search query
            top_k (int, optional): Number of top results to return. Defaults to 5.
            
        Returns:
            List[Tuple[str, float]]: List of (text_chunk, similarity_score) pairs
        """
        search_start_time = time.time()
        self.logger.info(f"Starting semantic search for top {top_k} chunks from query: '{query[:100]}...'")
        
        # Generate embedding for the query
        embedding_start_time = time.time()
        self.logger.debug("Generating query embedding using ONNX model")
        query_embedding = self.get_embedding_using_onnx(self.tokenizer, query)
        embedding_end_time = time.time()
        self.logger.info(f"Query embedding generation completed in {embedding_end_time - embedding_start_time:.3f} seconds")
        
        # Compute cosine similarities with all stored embeddings
        similarity_start_time = time.time()
        self.logger.debug(f"Computing cosine similarities against {len(self.embeddings)} knowledge base embeddings")
        similarities = cosine_similarity([query_embedding], self.embeddings)[0]
        similarity_end_time = time.time()
        self.logger.info(f"Similarity computation completed in {similarity_end_time - similarity_start_time:.3f} seconds")
        
        # Get indices of top K most similar chunks
        top_indices = similarities.argsort()[::-1][:top_k]
        
        # Log similarity scores for debugging
        best_scores = [similarities[i] for i in top_indices]
        self.logger.debug(f"Top {top_k} similarity scores: {[f'{score:.4f}' for score in best_scores]}")

        # Return text chunks with their similarity scores
        sentences = self.sentences
        results = [(sentences[i], similarities[i]) for i in top_indices]
        
        search_end_time = time.time()
        total_search_time = search_end_time - search_start_time
        self.logger.info(f"Semantic search completed successfully in {total_search_time:.3f} seconds - retrieved {len(results)} relevant chunks")
        return results

    def get_embedding_using_onnx(self, tokenizer: PreTrainedTokenizerBase, text: str, max_tokens: int = 512) -> np.ndarray:
        """
        Generate text embeddings using the ONNX model.
        
        This method handles chunking longer texts into smaller pieces,
        generating embeddings for each chunk, and then averaging them.
        
        Args:
            tokenizer (PreTrainedTokenizerBase): Tokenizer for processing the text
            text (str): Input text to embed
            max_tokens (int, optional): Maximum number of tokens per chunk. Defaults to 512.
            
        Returns:
            np.ndarray: The embedding vector for the input text
        """
        embedding_start_time = time.time()
        self.logger.info(f"Starting ONNX embedding generation for text ({len(text)} characters)")
        
        # Tokenize input text
        tokenization_start_time = time.time()
        tokens = tokenizer(text, return_tensors="np", add_special_tokens=False)
        input_ids = tokens["input_ids"][0]  # shape: (seq_len,)
        tokenization_end_time = time.time()
        self.logger.debug(f"Text tokenization completed in {tokenization_end_time - tokenization_start_time:.3f} seconds")
        
        # Chunk into max_tokens-sized segments to handle longer texts
        chunks = [input_ids[i:i+max_tokens] for i in range(0, len(input_ids), max_tokens)]
        self.logger.info(f"Text split into {len(chunks)} chunks (max {max_tokens} tokens each)")

        all_embeddings = []
        chunk_processing_start_time = time.time()

        # Process each chunk and generate embeddings
        for i, chunk in enumerate(chunks):
            chunk_start_time = time.time()
            self.logger.debug(f"Processing chunk {i+1}/{len(chunks)} with {len(chunk)} tokens")
            
            # Format inputs for the ONNX model
            chunk = np.expand_dims(chunk, axis=0)
            attention_mask = np.ones_like(chunk)
            token_type_ids = np.zeros_like(chunk)

            # Create input dictionary based on the model's expected inputs
            ort_inputs = {}
            if "input_ids" in self.input_names:
                ort_inputs["input_ids"] = chunk
            if "attention_mask" in self.input_names:
                ort_inputs["attention_mask"] = attention_mask
            if "token_type_ids" in self.input_names:
                ort_inputs["token_type_ids"] = token_type_ids

            try:
                # Run inference
                outputs = self.session.run(None, ort_inputs)
                last_hidden_state = outputs[0]  # shape: (1, seq_len, hidden_dim)

                # Mean Pooling: mean over seq_len dimension
                embedding = last_hidden_state.mean(axis=1)  # shape: (1, hidden_dim)
                all_embeddings.append(embedding.squeeze(0))  # shape: (hidden_dim,)
                
                chunk_end_time = time.time()
                self.logger.debug(f"Chunk {i+1} embedding completed in {chunk_end_time - chunk_start_time:.3f} seconds")
                
            except Exception as e:
                self.logger.error(f"Error generating embedding for chunk {i+1}: {str(e)}", exc_info=True)
                raise

        chunk_processing_end_time = time.time()
        self.logger.info(f"All {len(chunks)} chunks processed in {chunk_processing_end_time - chunk_processing_start_time:.3f} seconds")

        # Average all chunk embeddings to get a single vector for the text
        final_embedding = np.stack(all_embeddings).mean(axis=0)  # shape: (hidden_dim,)
        
        embedding_end_time = time.time()
        total_embedding_time = embedding_end_time - embedding_start_time
        self.logger.info(f"ONNX embedding generation completed in {total_embedding_time:.3f} seconds - output shape: {final_embedding.shape}")
        return final_embedding

    def get_final_answer_payload(self, all_chunks: str, user_query: str) -> List[Dict[str, str]]:
        """
        Create the payload for generating the final answer.
        
        Args:
            all_chunks (str): Concatenated relevant information chunks
            user_query (str): The rewritten user query
            
        Returns:
            List[Dict[str, str]]: Formatted payload for the LLM API call
        """
        payload_start_time = time.time()
        self.logger.debug(f"Creating final answer payload with {len(all_chunks)} characters of context")
        
        payload_data = []
        user = {
            "role": "user",
            "content": "Context:\n\n" +
                       all_chunks +
                       f"Question: {user_query}"
        }
        payload_data.append(user)
        
        payload_end_time = time.time()
        self.logger.debug(f"Final answer payload created in {payload_end_time - payload_start_time:.4f} seconds")
        return payload_data
    
    def get_generated_answer(self, user_query: str) -> str:
        """
        Generate an answer for a user query using a multi-step process.
        
        The process involves:
        1. Query rewriting to improve retrieval
        2. Semantic search for relevant information
        3. Answer generation using retrieved context
        
        Args:
            user_query (str): The user's original query
            
        Returns:
            str: Generated answer to the user's question
        """
        self.logger.info(f"Starting CRM query processing for: '{user_query[:100]}...'")
        
        try:
            # Step 1: Query rewriting to improve retrieval quality
            rewriting_start_time = time.time()
            self.logger.info("Starting query rewriting for improved retrieval accuracy")
            query_rewrite_payload = self.get_query_rewrite_payload(user_query)
            rewritten_user_query = fetch_from_llm(query_rewrite_payload, SystemPrompt.QUERY_REWRITE.value)
            rewriting_end_time = time.time()
            self.logger.info(f"Query rewriting completed in {rewriting_end_time - rewriting_start_time:.3f} seconds")
            self.logger.debug(f"Original: '{user_query}' -> Rewritten: '{rewritten_user_query}'")
            
            # Step 2: Search for relevant chunks of information
            search_start_time = time.time()
            self.logger.info("Starting semantic search for relevant knowledge base chunks")
            results = self.search_best_chunk(rewritten_user_query)
            search_end_time = time.time()
            self.logger.info(f"Semantic search completed in {search_end_time - search_start_time:.3f} seconds")
            
            # Combine the relevant chunks into context
            context_building_start_time = time.time()
            self.logger.debug("Building context from retrieved chunks")
            all_chunks = ""
            for i, (chunk_text, similarity_score) in enumerate(results):
                all_chunks += f"{chunk_text}\n\n"
                self.logger.debug(f"Added chunk {i+1} (similarity: {similarity_score:.4f}, length: {len(chunk_text)} chars)")
            
            context_building_end_time = time.time()
            self.logger.info(f"Context building completed in {context_building_end_time - context_building_start_time:.4f} seconds - total context: {len(all_chunks)} characters")
            
            # Step 3: Generate the final answer using retrieved context
            generation_start_time = time.time()
            self.logger.info("Starting final answer generation using retrieved context")
            final_answer_payload = self.get_final_answer_payload(all_chunks, rewritten_user_query)
            generated_answer = fetch_from_llm(final_answer_payload, SystemPrompt.CRM_PROMPT.value)
            generation_end_time = time.time()
            self.logger.info(f"Final answer generation completed in {generation_end_time - generation_start_time:.3f} seconds")
            
            total_time = generation_end_time - rewriting_start_time
            self.logger.info(f"🎯 CRM query processing completed successfully in {total_time:.3f} seconds (Answer length: {len(generated_answer)} characters)")
            
            return generated_answer
            
        except Exception as e:
            self.logger.error(f"Error during CRM query processing: {str(e)}", exc_info=True)
            raise
