"""
Document Chatbot Module
----------------------
This module provides the document chatbot functionality for processing PDFs and URLs,
and answering questions about their content using RAG.
"""

import time
import re
from typing import Dict, List, Tuple, Optional
from pathlib import Path

import gradio as gr

from parser.pdf.extract import extract_pdf
from parser.url.extract import get_text_from_url
from rag.main import get_chunk_embedder, get_response
from utils.url_utils import URLUtils
from utils.logger import DocZenseLogger, timed_function
from api.system_prompt import SystemPrompt

# Initialize logger for this module
logger = DocZenseLogger.get_logger("DocumentChatbot")


class DocumentChatbot:
    """
    Document chatbot class for handling PDF and URL processing with Q&A functionality.
    
    This class provides methods to process PDFs, extract content from URLs,
    and answer questions using the embedded document content.
    """
    
    def __init__(self):
        """Initialize the document chatbot."""
        logger.info("Initializing DocumentChatbot")
        self.chunk_embedder = None
        # Ensure fresh prompts are loaded
        SystemPrompt.reload_prompts()
    
    def reload_prompts(self):
        """
        Reload system prompts to ensure latest updates are applied.
        Useful when prompt files have been updated.
        """
        logger.info("Reloading system prompts")
        SystemPrompt.reload_prompts()
    
    @timed_function(logger)
    def process_pdf_files(self, files: List[str]) -> Tuple[bool, Optional[str]]:
        """
        Process a list of PDF files and extract their content.
        
        Args:
            files (List[str]): List of paths to PDF files
            
        Returns:
            Tuple[bool, Optional[str]]: Success status and error message if any
        """
        content = ""
        logger.info(f"Processing {len(files)} PDF files")
        
        for file in files:
            pdf_file_path = Path(file)
            logger.info(f"Extracting content from PDF: {pdf_file_path.name}")
            
            try:
                pdf_start_time = time.time()
                content = f"{extract_pdf(pdf_file_path)}\n\n{content}"
                pdf_end_time = time.time()
                
                extraction_time = pdf_end_time - pdf_start_time
                logger.info(f"PDF extraction completed for {pdf_file_path.name} in {extraction_time:.2f} seconds")
                
            except Exception as e:
                logger.error(f"Error processing PDF {pdf_file_path.name}: {str(e)}", exc_info=True)
                return False, f"Error processing the PDF: {str(e)}"
                
        logger.info("Creating chunk embedder from PDF content")
        self.chunk_embedder = get_chunk_embedder(content)
        logger.info("PDF processing completed successfully")
        return True, None
    
    @timed_function(logger)
    def extract_urls_from_query(self, query: str) -> List[str]:
        """
        Extract all URLs from a query string, including bare domains.
        
        Args:
            query (str): The user's query string
            
        Returns:
            List[str]: List of URLs extracted from the query
        """
        return URLUtils.extract_urls_from_text(query)
    
    @timed_function(logger)
    def process_urls(self, urls: List[str], query: str) -> Tuple[str, bool, Optional[str]]:
        """
        Process a list of URLs and extract their content.
        
        Args:
            urls (List[str]): List of URLs to process
            query (str): The original user query
            
        Returns:
            Tuple[str, bool, Optional[str]]: Modified query, success status, and error message if any
        """
        all_url_content = ""
        processed_urls = []
        clean_query = query
        
        logger.info(f"Processing {len(urls)} URLs: {urls}")
        
        for url in urls:
            try:
                logger.info(f"Extracting content from URL: {url}")
                url_start_time = time.time()
                url_content = get_text_from_url(url)
                url_end_time = time.time()
                
                extraction_time = url_end_time - url_start_time
                logger.info(f"URL extraction completed for {url} in {extraction_time:.2f} seconds")
                
                # Append content from this URL with a separator
                all_url_content += f"\n\n--- Content from {url} ---\n\n{url_content}"
                processed_urls.append(url)
                
                # Replace the URL in the query to avoid redundancy
                clean_query = clean_query.replace(url, f"the content from {url}")
                
            except Exception as e:
                logger.error(f"Error processing URL {url}: {str(e)}", exc_info=True)
                # Continue with other URLs even if one fails
        
        # Only create embeddings if we successfully processed any URLs
        if all_url_content:
            # Create embeddings for all combined URL content
            logger.info(f"Creating embeddings for content from {len(processed_urls)} URLs")
            chunking_start_time = time.time()
            self.chunk_embedder = get_chunk_embedder(all_url_content)
            chunking_end_time = time.time()
            
            chunking_time = chunking_end_time - chunking_start_time
            logger.info(f"URL content chunking completed in {chunking_time:.2f} seconds")
            return clean_query, True, None
        else:
            # If all URLs failed processing
            if urls:
                logger.warning("All provided URLs failed to process")
                return query, False, "Error processing all provided URLs. Please check the URLs and try again."
            return query, True, None
    
    def format_conversation_history(self, history: List[Dict]) -> str:
        """
        Format conversation history for the query.
        
        Args:
            history (List[Dict]): Previous conversation history
            
        Returns:
            str: Formatted conversation history
        """
        prev_replies = ""
        for h in history:
            prev_replies += f"{h['role']}: {h['content']}\n\n"
        return prev_replies
    
    def clear_embeddings(self):
        """
        Clear the chunk embedder to reset the document context.
        """
        logger.info("Clearing chunk embedder to reset document context")
        self.chunk_embedder = None
    
    @timed_function(logger)
    def answer(self, message: Dict, history: List[Dict]) -> str:
        """
        Process a user message and generate an answer based on document content.
        
        Args:
            message (Dict): User message containing text and files
            history (List[Dict]): Previous conversation history
            
        Returns:
            str: Generated answer based on document content
        """
        files = message["files"]
        query = message["text"]
        
        logger.info(f"Processing user query: '{query[:100]}...' with {len(files)} files")
        
        # Handle empty queries when no files are provided
        if (not query or query.strip() == "") and len(files) == 0:
            logger.warning("Empty query and no files provided")
            return "Welcome to DocZense Document Assistant! I'm your AI-powered document analysis companion that specializes in processing and answering questions about your documents. I can help you by:\n\n• Analyzing PDF files you upload\n• Extracting and processing content from URLs\n• Answering questions about document content using advanced RAG (Retrieval-Augmented Generation)\n• Providing summaries and insights from your documents\n\nTo get started, please upload a PDF file, provide a URL, or ask a question about previously uploaded content. Note: I'm designed specifically for document analysis and may not be able to assist with general queries unrelated to document content."
        
        # Process PDF files if provided
        if len(files) > 0:
            logger.info(f"Processing {len(files)} uploaded files")
            success, error_msg = self.process_pdf_files(files)
            if not success:
                logger.error(f"PDF processing failed: {error_msg}")
                return error_msg
        
        # Extract and process URLs
        urls = self.extract_urls_from_query(query)
        logger.debug(f"Extracted {len(urls)} URLs from query")
        
        # If URLs found and no PDF was processed, extract content from all URLs
        if urls and (self.chunk_embedder is None or len(files) == 0):
            logger.info("Processing URLs since no PDF content is available")
            query, success, error_msg = self.process_urls(urls, query)
            if not success:
                logger.error(f"URL processing failed: {error_msg}")
                return error_msg
        
        # Default query if none provided but we have content
        if not query or query.strip() == "":
            query = "Summarise this document"
            logger.info("Using default summarization query")
        
        # Verify that we have document content to work with
        if self.chunk_embedder is None:
            logger.warning("No document content available for answering questions")
            return "DocZense Document Assistant requires document content to answer your questions. Please upload a PDF file or provide a URL first. I specialize in analyzing documents and can provide insights, summaries, and answer questions based on the content you provide."
        
        # Format the complete query with history and current question
        prev_replies = self.format_conversation_history(history)
        formatted_query = f"{prev_replies}\n\nUser: {query}\n\nAssistant:"
        
        logger.info("Generating response using RAG")
        # Get response using RAG
        response = get_response(self.chunk_embedder, formatted_query)
        
        # Handle "NOT FOUND" response from LLM
        if response.strip().upper() == "NOT FOUND":
            logger.warning("LLM returned 'NOT FOUND' response")
            return "I couldn't find relevant information in the uploaded document(s) to answer your question. Please try rephrasing your question or upload a different document that might contain the information you're looking for."
        
        logger.info(f"Successfully generated response ({len(response)} characters)")
        return response

