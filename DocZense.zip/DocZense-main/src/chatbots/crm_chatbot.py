"""
CRM Chatbot Module
-----------------
This module provides the CRM chatbot functionality for answering questions about Zoho CRM.
"""

import time
from typing import Dict, List

import gradio as gr

from crm.crm import CRM
from models.config import ModelConfig
from utils.url_utils import URLUtils
from api.llm_inference import fetch_from_llm
from api.system_prompt import SystemPrompt
from utils.logger import DocZenseLogger, timed_function

# Initialize logger for this module
logger = DocZenseLogger.get_logger("CRMChatbot")


class CRMChatbot:
    """
    CRM chatbot class for handling Zoho CRM related questions.
    
    This class provides methods to process CRM-related queries and generate
    responses based on the CRM knowledge base.
    """
    
    def __init__(self):
        """Initialize the CRM chatbot with model configuration."""
        logger.info("Initializing CRMChatbot")
        model_config = ModelConfig()
        self.crm = CRM(model_config.tokenizer, model_config.model)
        # Ensure fresh prompts are loaded
        SystemPrompt.reload_prompts()
        logger.info("CRMChatbot initialization completed")
    
    def reload_prompts(self):
        """
        Reload system prompts to ensure latest updates are applied.
        Useful when prompt files have been updated.
        """
        logger.info("Reloading CRM system prompts")
        SystemPrompt.reload_prompts()
    
    @timed_function(logger)
    def answer(self, query: str, history: List[Dict]) -> str:
        """
        Process a CRM-related query using conversation history.
        
        Args:
            query (str): The user's question about CRM
            history (List[Dict]): Previous conversation history containing role and content
            
        Returns:
            str: Generated answer to the user's question based on CRM knowledge
        """
        logger.info(f"Processing CRM query: '{query[:100]}...'")
        
        # Handle empty queries
        if not query or query.strip() == "":
            logger.warning("Empty CRM query received")
            return "Welcome to DocZense CRM Assistant! I'm your specialized AI assistant for Zoho CRM questions. I can help you with CRM features, best practices, configuration, and usage guidance. Please ask me any question about Zoho CRM to get started. Note: I'm focused specifically on CRM-related topics and may not be able to assist with general queries outside this domain."
        
        # Format conversation history for context
        prev_replies = ""
        for h in history:
            prev_replies += f"{h['role']}: {h['content']}\n\n"
        
        # Format the complete query with history and current question
        formatted_query = f"{prev_replies}\n\nUser: {query}\n\nAssistant:"   
        
        logger.info("Generating CRM response")
        # Get response from CRM model
        response = self.crm.get_generated_answer(formatted_query)
        
        # Handle "NOT FOUND" response from LLM
        if response.strip().upper() == "NOT FOUND":
            logger.warning("CRM returned 'NOT FOUND' response")
            return "I couldn't find relevant information in the Zoho CRM knowledge base to answer your question. Please try rephrasing your question or ask about specific CRM features, configuration, or best practices."
        
        logger.info("Validating URLs in CRM response")
        # Check for URLs in the response and validate them
        response = self._validate_and_fix_urls_in_response(response, query, history)
        
        logger.info(f"Successfully generated CRM response ({len(response)} characters)")
        return response
    
    @timed_function(logger)
    def _validate_and_fix_urls_in_response(self, response: str, original_query: str, history: List[Dict]) -> str:
        """
        Validate URLs in the response and regenerate if any are invalid.
        
        Args:
            response (str): The original response from CRM
            original_query (str): The user's original query
            history (List[Dict]): Conversation history
            
        Returns:
            str: Validated response with working URLs or regenerated response without URLs
        """
        start_time = time.time()
        logger.info(f"Starting URL validation for CRM response ({len(response)} characters)")
        
        # Extract URLs from the response
        url_extraction_start = time.time()
        urls = URLUtils.extract_urls_from_text(response)
        url_extraction_end = time.time()
        
        extraction_time = url_extraction_end - url_extraction_start
        logger.debug(f"URL extraction completed in {extraction_time:.4f} seconds")
        logger.info(f"Found {len(urls)} URLs: {urls}")
        
        if not urls:
            # No URLs found, return original response
            total_time = time.time() - start_time
            logger.info(f"No URLs found in response. Processing completed in {total_time:.4f} seconds")
            return response
        
        # Check if any URLs are invalid (404 or other errors)
        validation_start = time.time()
        valid_urls, invalid_urls, marked_response = URLUtils.validate_urls_in_text(response)
        validation_end = time.time()
        
        validation_time = validation_end - validation_start
        logger.debug(f"URL validation completed in {validation_time:.4f} seconds")
        logger.info(f"Valid URLs: {len(valid_urls)} - {valid_urls}")
        logger.info(f"Invalid URLs: {len(invalid_urls)} - {invalid_urls}")
        
        if not invalid_urls:
            # All URLs are valid, return original response
            total_time = time.time() - start_time
            logger.info(f"All URLs are valid. Processing completed in {total_time:.4f} seconds")
            return response
        
        # If there are invalid URLs, regenerate the response without URLs
        logger.warning(f"Found {len(invalid_urls)} invalid URLs in CRM response. Starting regeneration...")
        regeneration_start = time.time()
        
        # Create a new prompt asking for a response without URLs
        url_free_prompt = f"""
        Please provide a helpful response to the user's question about Zoho CRM without including any URLs or web links.
        Focus on providing clear, actionable information and guidance.
        
        User Question: {original_query}
        
        Note: Please do not include any URLs, web links, or references to specific web pages in your response.
        """
        
        # Format conversation history for context
        prev_replies = ""
        for h in history:
            prev_replies += f"{h['role']}: {h['content']}\n\n"
        
        # Prepare the data for LLM API call
        messages = [
            {
                "role": "user",
                "content": f"{prev_replies}\n\n{url_free_prompt}"
            }
        ]
        
        # System prompt for CRM context
        system_prompt = SystemPrompt.CRM_URL_FREE.value
        
        try:
            # Generate new response without URLs using the LLM API
            llm_call_start = time.time()
            new_response = fetch_from_llm(messages, system_prompt)
            llm_call_end = time.time()
            
            llm_time = llm_call_end - llm_call_start
            logger.info(f"LLM regeneration completed in {llm_time:.4f} seconds")
            logger.debug(f"Generated new response ({len(new_response)} characters)")
            
            # Double-check that the new response doesn't have URLs
            double_check_start = time.time()
            new_urls = URLUtils.extract_urls_from_text(new_response)
            double_check_end = time.time()
            
            double_check_time = double_check_end - double_check_start
            logger.debug(f"Double-check URL extraction completed in {double_check_time:.4f} seconds")
            
            if new_urls:
                # If URLs are still present, clean them out
                logger.warning(f"New response still contains {len(new_urls)} URLs. Cleaning...")
                cleanup_start = time.time()
                cleaned_response, removed_urls = URLUtils.clean_text_from_invalid_urls(new_response)
                cleanup_end = time.time()
                
                cleanup_time = cleanup_end - cleanup_start
                logger.debug(f"URL cleanup completed in {cleanup_time:.4f} seconds")
                logger.info(f"Removed URLs: {removed_urls}")
                
                regeneration_end = time.time()
                total_time = time.time() - start_time
                regeneration_time = regeneration_end - regeneration_start
                logger.info(f"Response regeneration completed in {regeneration_time:.4f} seconds")
                logger.info(f"Total URL validation processing time: {total_time:.4f} seconds")
                
                return cleaned_response
            else:
                logger.info("New response is URL-free")
            
            regeneration_end = time.time()
            total_time = time.time() - start_time
            regeneration_time = regeneration_end - regeneration_start
            logger.info(f"Response regeneration completed in {regeneration_time:.4f} seconds")
            logger.info(f"Total URL validation processing time: {total_time:.4f} seconds")
            
            return new_response
            
        except Exception as e:
            regeneration_end = time.time()
            total_time = time.time() - start_time
            regeneration_time = regeneration_end - regeneration_start
            
            logger.error(f"Error regenerating CRM response: {str(e)}", exc_info=True)
            logger.warning(f"Regeneration failed after {regeneration_time:.4f} seconds")
            logger.info(f"Total processing time: {total_time:.4f} seconds")
            logger.info("Falling back to marked response")
            
            # Fallback: return the original response with invalid URLs marked
            return f"{marked_response}\n\n[Note: Some URLs in this response may not be accessible.]"

