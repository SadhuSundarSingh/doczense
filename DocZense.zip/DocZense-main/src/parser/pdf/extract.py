"""
PDF Extraction Module

This module provides functionality to extract content from PDF files and convert
it to markdown format. It processes a single PDF file and extracts text, tables,
and references to images.

The extracted content is saved as a markdown file with the same name as the input
file but with a .md extension in the 'out' directory.

Usage:
    python extract.py path/to/file.pdf
"""

import argparse
import sys
from pathlib import Path
from typing import List 
import fitz

from tqdm import tqdm
from utils.logger import DocZenseLogger


def extract_pdf(pdf_path: Path) -> str:
    """
    Extract content from a PDF file and convert it to markdown format.
    
    Args:
        pdf_path (Path): Path to the PDF file to process
        
    Returns:
        str: Markdown formatted content extracted from the PDF
    """
    doc: fitz.Document = fitz.open(str(pdf_path))
    markdown_content: List[str] = []
    
    # Add document title
    file_name: str = pdf_path.name
    markdown_content.append(f"# {file_name}\n\n")

    for page_num, page in enumerate(doc):
        # Add page header
        markdown_content.append(f"## Page {page_num + 1}\n\n")
        
        # Extract different content types
        text: str = page.get_text()
        tables: List = page.find_tables()  # Simplified
        images: List = page.get_images()
        
        # Add text content
        if text:
            markdown_content.append(f"### Text\n\n{text}\n\n")
        
        # Handle tables
        if tables:
            markdown_content.append("### Tables\n\n")
            for table_idx, table in enumerate(tables):
                markdown_content.append(f"#### Table {table_idx + 1}\n\n")
                markdown_content.append(f"{table.to_markdown()}\n\n")
        
        # Reference images
        if images:
            markdown_content.append("### Images\n\n")
            for img_idx, img in enumerate(images):
                markdown_content.append(f"![Image {img_idx + 1} on page {page_num + 1}]\n\n")

    return "".join(markdown_content)


def main() -> None:
    """
    Main function to parse command line arguments and process a PDF file.
    
    Command line arguments:
        path: Path to the PDF file to process
    
    Returns:
        None
    """
    logger = DocZenseLogger.get_logger("PDFExtract")
    parser = argparse.ArgumentParser(description="Extract content from a PDF file in markdown format.")
    parser.add_argument("path", help="Path to the PDF file to process")
    args = parser.parse_args()

    input_path: Path = Path(args.path)
    
    # Get the output filename by replacing .pdf extension with .md
    output_file: str = input_path.stem + ".md"
    
    # Verify the input file is a PDF
    if input_path.suffix.lower() != '.pdf':
        logger.error(f"The input file '{input_path}' is not a PDF file")
        return
    
    # Verify the input file exists
    if not input_path.is_file():
        logger.error(f"The input file '{input_path}' does not exist")
        return
    
    # prepare output directory
    output_dir: Path = Path('out')
    output_dir.mkdir(exist_ok=True)
    
    output_path: Path = output_dir / output_file
    
    # Create/open the output file
    with output_path.open('w', encoding='utf-8') as out_file:
        try:
            # Extract markdown content
            logger.info(f"Processing PDF: {input_path}")
            markdown_content: str = extract_pdf(input_path)
            
            # Write to the output file
            out_file.write(markdown_content)
                
        except Exception as e:
            logger.error(f"Error processing file '{input_path}': {e}")
            out_file.write(f"## Error processing {input_path.name}\n\nError: {e}\n\n")
    
    logger.info(f"PDF content has been extracted to: {output_path}")


if __name__ == "__main__":
    main()
