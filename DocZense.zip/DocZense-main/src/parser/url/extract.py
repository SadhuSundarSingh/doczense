"""
URL Content Extraction Module
---------------------------
This module provides functionality to extract text content from URLs 
using the Diffbot API for web page parsing.
"""

import requests
import json
import os
from typing import Dict, Any, Optional

from utils.logger import DocZenseLogger

# Initialize logger for this module
logger = DocZenseLogger.get_logger("URLExtractor")

class URLContentExtractor:
    """
    Class for extracting text content from URLs.
    
    This class provides methods to fetch and parse web pages into
    clean text format suitable for analysis and processing.
    """
    
    # Default Diffbot API configuration - loaded from config file
    _config = None
    
    @classmethod
    def _load_config(cls) -> Dict[str, Any]:
        """Load Diffbot configuration from JSON file."""
        if cls._config is None:
            # Get the path to the config file relative to project root
            config_path = "resources/diffbot_config.json"
            
            try:
                logger.debug(f"Loading Diffbot configuration from {config_path}")
                with open(config_path, 'r') as f:
                    cls._config = json.load(f)
                logger.info("Diffbot configuration loaded successfully")
            except FileNotFoundError:
                logger.error(f"Diffbot config file not found: {config_path}")
                raise
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in config file: {str(e)}")
                raise
        return cls._config
    
    @classmethod
    def get_default_token(cls) -> str:
        """Get the default API token from configuration."""
        config = cls._load_config()
        return config["token"]
    
    @classmethod
    def get_api_url(cls) -> str:
        """Get the API URL from configuration."""
        config = cls._load_config()
        return config["api_url"]
    
    @staticmethod
    def get_text_from_url(url: str, token: str = None) -> str:
        """
        Extract text content from a URL using the Diffbot API.
        
        API usage limits:
        - 5 calls per minute across all APIs
        - 10,000 calls per month for the Extract API
        
        Args:
            url (str): The URL to extract content from
            token (str, optional): Diffbot API token. If None, uses the default token from config.
            
        Returns:
            str: Extracted text content or error message
        """
        logger.info(f"Extracting content from URL: {url}")
        
        # Use default token if none provided
        if token is None:
            token = URLContentExtractor.get_default_token()
            logger.debug("Using default API token from configuration")
        else:
            logger.debug("Using provided API token")
            
        # Prepare API request parameters
        params = {
            "token": token,
            "url": url
        }

        try:
            logger.debug(f"Making API request to Diffbot for URL: {url}")
            # Make the API request
            response = requests.get(URLContentExtractor.get_api_url(), params=params)

            if response.status_code == 200:
                logger.debug("Successfully received response from Diffbot API")
                data = response.json()
                # Extract article content from response
                objects = data.get("objects", [])
                if objects:
                    article = objects[0]
                    title = article.get("title", "No Title")
                    text = article.get("text", "No Content")
                    response_text = f"Title: {title}\n{text}"
                    
                    logger.info(f"Successfully extracted content: {len(response_text)} characters")
                    logger.debug(f"Article title: {title}")
                    
                    return response_text
                else:
                    logger.warning("No article content found in API response")
                    return "No article content found."
            else:
                logger.error(f"Diffbot API request failed with status code {response.status_code}")
                return f"Request failed with status code {response.status_code}"
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error during URL extraction: {str(e)}", exc_info=True)
            return f"Network error: {str(e)}"
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse API response: {str(e)}", exc_info=True)
            return f"Failed to parse response: {str(e)}"
        except Exception as e:
            logger.error(f"Unexpected error during URL extraction: {str(e)}", exc_info=True)
            return f"Unexpected error: {str(e)}"


# Function for backwards compatibility
def get_text_from_url(url: str, token: str = None) -> str:
    """
    Extract text content from a URL using the URLContentExtractor class.
    
    This function is maintained for backwards compatibility with existing code.
    
    Args:
        url (str): The URL to extract content from
        token (str, optional): Diffbot API token. If None, uses the default token from config.
        
    Returns:
        str: Extracted text content or error message
    """
    return URLContentExtractor.get_text_from_url(url, token)