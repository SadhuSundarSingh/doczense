"""
Shared Model Configuration
-------------------------
This module provides a singleton class for managing the tokenizer and ONNX model
to be shared across the application, avoiding duplicate loading in memory.
"""

import time
from typing import Optional
import onnxruntime as ort
from transformers import AutoTokenizer, PreTrainedTokenizerBase
from utils.logger import DocZenseLogger


class ModelConfig:
    """
    Singleton class for managing shared model instances.
    
    This class ensures that only one instance of the tokenizer and ONNX model
    exist throughout the application lifecycle, following OOP principles.
    """
    
    _instance: Optional['ModelConfig'] = None
    _initialized: bool = False
    
    # Model configuration constants
    MODEL_NAME = "nomic-ai/nomic-embed-text-v1"
    ONNX_MODEL_PATH = "resources/models/model.onnx"
    
    def __new__(cls) -> 'ModelConfig':
        """
        Ensure only one instance of ModelConfig exists (Singleton pattern).
        
        Returns:
            ModelConfig: The singleton instance
        """
        if cls._instance is None:
            cls._instance = super(ModelConfig, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """
        Initialize the model configuration if not already initialized.
        """
        if not self._initialized:
            self.logger = DocZenseLogger.get_logger("ModelConfig")
            self._load_models()
            ModelConfig._initialized = True
    
    def _load_models(self) -> None:
        """
        Load the tokenizer and ONNX model instances.
        
        This method handles the actual loading of the models with timing information.
        """
        self.logger.info("Loading shared model and tokenizer...")
        start_time = time.time()
        
        self._tokenizer = AutoTokenizer.from_pretrained(
            self.MODEL_NAME, 
            trust_remote_code=True
        )
        self._model = ort.InferenceSession(
            self.ONNX_MODEL_PATH, 
            providers=["CPUExecutionProvider"]
        )
        
        end_time = time.time()
        self.logger.info(f"Shared model setup took {end_time - start_time:.4f} seconds")
    
    @property
    def tokenizer(self) -> PreTrainedTokenizerBase:
        """
        Get the shared tokenizer instance.
        
        Returns:
            PreTrainedTokenizerBase: The tokenizer instance
        """
        return self._tokenizer
    
    @property
    def model(self) -> ort.InferenceSession:
        """
        Get the shared ONNX model instance.
        
        Returns:
            ort.InferenceSession: The ONNX model instance
        """
        return self._model
    
    @classmethod
    def get_instance(cls) -> 'ModelConfig':
        """
        Get the singleton instance of ModelConfig.
        
        Returns:
            ModelConfig: The singleton instance
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
