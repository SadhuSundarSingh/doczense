import nltk
import re
import torch

import numpy as np
from onnxruntime import InferenceSession
import onnxruntime as ort
# from ort import InferenceSession
from nltk.tokenize import sent_tokenize
from transformers import PreTrainedTokenizerBase, PreTrainedModel

nltk.download("punkt_tab")

class ChunkEmbedder:
    def __init__(self, text: str, session: InferenceSession, tokenizer: PreTrainedTokenizerBase):
        self.text = text
        self.session = session
        # Get input/output names from model (usually input_ids, attention_mask)
        self.input_names = {inp.name for inp in self.session.get_inputs()}
        # self.model = model
        self.tokenizer = tokenizer
        self.sentences = self.generate_chunks(self.text, max_token=256, overlap=40)
        # self.embeddings = [self.get_embedding(self.tokenizer, self.model, sentence) for sentence in self.sentences]
        self.embeddings = [self.get_embedding_using_onnx(self.tokenizer, sentence) for sentence in self.sentences]
        
    def count_tokens(self, text: str) -> int:
        return len(self.tokenizer.encode(text, add_special_tokens=False))
    
    def generate_chunks(self, text: str, max_token: str=512, overlap: int=50) -> list[str]:
        # Clean up and split into sentences
        text = re.sub(r'\s+', ' ', text.strip()) 
        sentences = sent_tokenize(text)

        chunks = []
        current_chunk = []
        current_length = 0

        for sentence in sentences:
            sentence_token_len = self.count_tokens(sentence)

            # Split overly long sentence into parts
            if sentence_token_len > max_token:
                words = sentence.split()
                temp = ""
                for word in words:
                    if self.count_tokens(temp + word) > max_token:
                        chunks.append(temp.strip())
                        temp = word + " "
                    else:
                        temp += word + " "
                if temp.strip():
                    chunks.append(temp.strip())
                continue

            # If adding sentence exceeds max, save current chunk and slide
            if current_length + sentence_token_len > max_token:
                final_chunk = " ".join(current_chunk).strip()
                chunks.append(final_chunk)

                # Sliding window: retain some overlap
                overlap_chunk = []
                overlap_count = 0
                for s in reversed(current_chunk):
                    s_tokens = self.count_tokens(s)
                    if overlap_count + s_tokens <= overlap:
                        overlap_chunk.insert(0, s)
                        overlap_count += s_tokens
                    else:
                        break

                current_chunk = overlap_chunk.copy()
                current_length = overlap_count

            # Add sentence to current chunk
            current_chunk.append(sentence)
            current_length += sentence_token_len

        # Add any leftover sentences
        if current_chunk:
            chunks.append(" ".join(current_chunk).strip())

        return chunks

    def get_embedding(self, tokenizer: PreTrainedTokenizerBase, model: PreTrainedModel, text: str, max_tokens: int=512) -> np.ndarray:
    
        # Tokenize the input without truncation
        tokens = tokenizer(text, return_tensors="pt", add_special_tokens=False)
        input_ids = tokens["input_ids"][0]

        # Break into chunks of max_tokens
        chunks = [input_ids[i:i+max_tokens] for i in range(0, len(input_ids), max_tokens)]

        all_embeddings = []

        for chunk in chunks:
            chunk_inputs = {
                "input_ids": chunk.unsqueeze(0),
                "attention_mask": torch.ones_like(chunk).unsqueeze(0),
                "token_type_ids": torch.zeros_like(chunk).unsqueeze(0)

            }

            with torch.no_grad():
                outputs = model(**chunk_inputs)
                # Mean Pooling
                embedding = outputs.last_hidden_state.mean(dim=1)
                all_embeddings.append(embedding.squeeze(0))

        # Average all chunk embeddings
        final_embedding = torch.stack(all_embeddings).mean(dim=0)
        return final_embedding.numpy()

    def get_embedding_using_onnx(self, tokenizer: PreTrainedTokenizerBase, text: str, max_tokens: int = 512) -> np.ndarray:
        # Tokenize input text
        tokens = tokenizer(text, return_tensors="np", add_special_tokens=False)
        input_ids = tokens["input_ids"][0]  # shape: (seq_len,)

        # Chunk into max_tokens-sized segments
        chunks = [input_ids[i:i+max_tokens] for i in range(0, len(input_ids), max_tokens)]

        all_embeddings = []

        for chunk in chunks:
            chunk = np.expand_dims(chunk, axis=0)
            attention_mask = np.ones_like(chunk)
            token_type_ids = np.zeros_like(chunk)

            ort_inputs = {}

            if "input_ids" in self.input_names:
                ort_inputs["input_ids"] = chunk
            if "attention_mask" in self.input_names:
                ort_inputs["attention_mask"] = attention_mask
            if "token_type_ids" in self.input_names:
                ort_inputs["token_type_ids"] = token_type_ids

            # Run inference
            outputs = self.session.run(None, ort_inputs)
            last_hidden_state = outputs[0]  # shape: (1, seq_len, hidden_dim)

            # Mean Pooling: mean over seq_len dimension
            embedding = last_hidden_state.mean(axis=1)  # shape: (1, hidden_dim)
            all_embeddings.append(embedding.squeeze(0))  # shape: (hidden_dim,)

        # Average all chunk embeddings
        final_embedding = np.stack(all_embeddings).mean(axis=0)  # shape: (hidden_dim,)
        return final_embedding