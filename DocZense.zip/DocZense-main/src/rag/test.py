from main import get_response_for_crm
from utils.logger import DocZenseLogger

logger = DocZenseLogger.get_logger("RAGTest")
ans = get_response_for_crm("How can I integrate Zoho CRM with WhatsApp?")
logger.info(f"Response: {ans}")