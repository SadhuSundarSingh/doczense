from rag.chunk_embedder import ChunkEmbedder

import sys
import time
sys.path.append("/home/workspace/DocZense/src/api")

from api.system_prompt import SystemPrompt
from api.llm_inference import fetch_from_llm
from sklearn.metrics.pairwise import cosine_similarity
from utils.logger import DocZenseLogger

class AnswerGenerator:
    def __init__(self, chunk_embedder: ChunkEmbedder, user_query: str):
        self.logger = DocZenseLogger.get_logger("AnswerGenerator")
        self.chunk_embedder = chunk_embedder
        self.user_query = user_query
        self.query_rewrite_payload = self.get_query_rewrite_payload(self.user_query)
        rewriting_start_time = time.time()
        self.logger.info("Query rewriting started")
        self.rewritten_user_query = fetch_from_llm(self.query_rewrite_payload, SystemPrompt.QUERY_REWRITE.value)
        rewriting_end_time = time.time()
        self.logger.info(f"Query rewriting finished in {rewriting_end_time - rewriting_start_time:.2f} seconds")
        search_start_time = time.time()
        self.logger.info("Searching best chunk started")
        self.results = self.search_best_chunk(self.chunk_embedder, self.rewritten_user_query)
        search_end_time = time.time()
        self.logger.info(f"Searching best chunk finished in {search_end_time - search_start_time:.2f} seconds")
        all_chunks = ""
        for i in self.results:
            all_chunks += f"{i[0]}\n\n"
        generation_start_time = time.time()
        self.logger.info("Generating final answer started")
        self.final_answer_payload = self.get_final_answer_payload(all_chunks, self.rewritten_user_query)
        generation_end_time = time.time()
        self.logger.info(f"Generating final answer finished in {generation_end_time - generation_start_time:.2f} seconds")
        self.generated_answer = fetch_from_llm(self.final_answer_payload, SystemPrompt.FINAL_RESPONSE.value)
        

    def get_query_rewrite_payload(self, user_query: str) -> list:
        payload_data = []
        user = {
            "role": "user",
            "content":  f"Original Query: {user_query}\n\nPlease rewrite this query to make it clearer and more suitable for retrieving relevant information from a knowledge base."
            }
        payload_data.append(user)
        return payload_data

    def search_best_chunk(self, chunk_embedder: ChunkEmbedder, query: str, top_k=5) -> list:
        # query_embedding = chunk_embedder.get_embedding(chunk_embedder.tokenizer, chunk_embedder.model, query)
        query_embedding = chunk_embedder.get_embedding_using_onnx(chunk_embedder.tokenizer, query)
        # Compute cosine similarities
        similarities = cosine_similarity([query_embedding], chunk_embedder.embeddings)[0]
        top_indices = similarities.argsort()[::-1][:top_k]

        sentences = chunk_embedder.sentences
        return [(sentences[i], similarities[i]) for i in top_indices]

    def get_final_answer_payload(self, all_chunks: str, user_query: str) -> list:
        payload_data = []
        user = {
            "role": "user",
            "content": "Context:\n\n" +
                        all_chunks +
                        f"Question: {user_query}"
            }
        payload_data.append(user)
        return payload_data
    

