"""
RAG (Retrieval-Augmented Generation) Module
-----------------------------------------
This module provides functionality for processing documents, generating embeddings,
and answering questions using retrieval-augmented generation.
"""

import nltk
import time
from typing import Optional

from rag.chunk_embedder import ChunkEmbedder
from rag.answer_generator import AnswerGenerator
from models.config import ModelConfig
from utils.logger import DocZenseLogger, timed_function

# Initialize logger for this module
logger = DocZenseLogger.get_logger("RAGService")

# Initialize NLTK for text processing
start_time = time.time()
logger.info("Initializing NLTK for text processing")
nltk.download("punkt_tab")
end_time = time.time()
setup_time = end_time - start_time
logger.info(f"NLTK setup completed in {setup_time:.4f} seconds")

# Initialize model configuration
logger.info("Initializing model configuration")
model_config = ModelConfig()


class RAGService:
    """
    Retrieval-Augmented Generation service for document processing and question answering.
    
    This class provides methods for processing documents, generating embeddings,
    and answering questions using the embedded document content.
    """
    
    @staticmethod
    @timed_function(logger)
    def get_chunk_embedder(document: str) -> ChunkEmbedder:
        """
        Process a document and create embeddings for its chunks.
        
        Args:
            document (str): The document text to process
            
        Returns:
            ChunkEmbedder: An initialized chunk embedder with the document content
        """
        logger.info("Starting document embedding process")
        logger.debug(f"Document length: {len(document)} characters")
        
        start_time = time.time()
        
        try:
            # Initialize ChunkEmbedder with document content
            chunk_embedder_obj = ChunkEmbedder(document, model_config.model, model_config.tokenizer)
            
            end_time = time.time()
            embedding_time = end_time - start_time
            logger.info(f"Document embedding completed in {embedding_time:.4f} seconds")
            
            return chunk_embedder_obj
            
        except Exception as e:
            logger.error(f"Error during document embedding: {str(e)}", exc_info=True)
            raise
    
    @staticmethod
    @timed_function(logger)
    def get_response(chunk_embedder_obj: ChunkEmbedder, user_query: str) -> str:
        """
        Generate a response to a user query using the embedded document content.
        
        Args:
            chunk_embedder_obj (ChunkEmbedder): The embedder with document content
            user_query (str): The user's question
            
        Returns:
            str: Generated answer to the user's question
        """
        logger.info("Starting response generation")
        logger.debug(f"User query: '{user_query[:100]}...'")
        
        start_time = time.time()
        
        try:
            # Create answer generator and get response
            answer_generator_obj = AnswerGenerator(chunk_embedder_obj, user_query)
            
            end_time = time.time()
            generation_time = end_time - start_time
            logger.info(f"Response generation completed in {generation_time:.4f} seconds")
            
            return answer_generator_obj.generated_answer
            
        except Exception as e:
            logger.error(f"Error during response generation: {str(e)}", exc_info=True)
            raise


# Functions for backwards compatibility
@timed_function(logger)
def get_chunk_embedder(document: str) -> ChunkEmbedder:
    """
    Process a document and create embeddings using the RAGService.
    
    This function is maintained for backwards compatibility with existing code.
    
    Args:
        document (str): The document text to process
        
    Returns:
        ChunkEmbedder: An initialized chunk embedder with the document content
    """
    return RAGService.get_chunk_embedder(document)


@timed_function(logger)
def get_response(chunk_embedder_obj: ChunkEmbedder, user_query: str) -> str:
    """
    Generate a response to a user query using the RAGService.
    
    This function is maintained for backwards compatibility with existing code.
    
    Args:
        chunk_embedder_obj (ChunkEmbedder): The embedder with document content
        user_query (str): The user's question
        
    Returns:
        str: Generated answer to the user's question
    """
    return RAGService.get_response(chunk_embedder_obj, user_query)
