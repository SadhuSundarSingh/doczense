"""
URL Utilities Module
-------------------
This module provides utilities for URL detection, validation, and content extraction.
"""

import re
import requests
from typing import List, Tuple, Optional
from urllib.parse import urlparse

from utils.logger import DocZenseLogger

# Initialize logger for this module
logger = DocZenseLogger.get_logger("URLUtils")


class URLUtils:
    """
    Utility class for URL-related operations.
    
    Provides methods for URL detection, validation, and checking URL availability.
    """
    
    # Regular expression patterns
    # URL regex pattern to detect full URLs including domains, subdomains, paths, and query parameters
    URL_PATTERN = r'https?://(?:www\.)?(?:[a-zA-Z0-9][-a-zA-Z0-9]*[a-zA-Z0-9]\.)+[a-zA-Z0-9][-a-zA-Z0-9]*[a-zA-Z0-9](?::\d+)?(?:/[-a-zA-Z0-9%_.~#&=]*)*(?:\?[-a-zA-Z0-9%_.~#&=]*)?'
    
    # Regex pattern to detect bare domains with optional paths (e.g., "example.com", "example.com/path", "sub.example.co.uk/flow")
    DOMAIN_PATTERN = r'(?<!\w)(?:[a-zA-Z0-9][-a-zA-Z0-9]*[a-zA-Z0-9]\.)+(?:com|org|net|edu|gov|mil|io|co|uk|us|ca|au|de|jp|fr|in|ru|br|it|nl|eu|ch|es|tech|app|dev|ai|co\.uk|co\.in|org\.uk|ac\.uk)(?:/[-a-zA-Z0-9%_.~#&=]*)*(?!\w)'
    
    @classmethod
    def extract_urls_from_text(cls, text: str) -> List[str]:
        """
        Extract all URLs from a text string, including bare domains.
        
        Args:
            text (str): The text to search for URLs
            
        Returns:
            List[str]: List of URLs found in the text
        """
        # Find URLs in the text
        urls = re.findall(cls.URL_PATTERN, text)
        
        # Find bare domains (without http/https prefix) and convert them to proper URLs
        bare_domains = re.findall(cls.DOMAIN_PATTERN, text)
        for domain in bare_domains:
            # Skip if this domain is already part of a full URL we found
            already_included = False
            for url in urls:
                if domain in url:
                    already_included = True
                    break
            
            if not already_included:
                # Add https:// prefix to the domain
                full_url = f"https://{domain}"
                urls.append(full_url)
                logger.debug(f"Found bare domain: {domain}, converted to {full_url}")
        
        logger.debug(f"Extracted {len(urls)} URLs from text")
        return urls
    
    @classmethod
    def check_url_availability(cls, url: str, timeout: int = 10) -> Tuple[bool, int, str]:
        """
        Check if a URL is available and not returning a 404 or other error status.
        
        Args:
            url (str): The URL to check
            timeout (int): Request timeout in seconds
            
        Returns:
            Tuple[bool, int, str]: (is_available, status_code, error_message)
        """
        try:
            # Parse URL to ensure it's valid
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return False, 0, "Invalid URL format"
            
            # Make a HEAD request to check availability (faster than GET)
            response = requests.head(url, timeout=timeout, allow_redirects=True)
            
            # Consider 2xx and 3xx status codes as available
            is_available = 200 <= response.status_code < 400
            
            if not is_available:
                if response.status_code == 404:
                    error_msg = "Page not found (404)"
                elif response.status_code == 403:
                    error_msg = "Access forbidden (403)"
                elif response.status_code == 500:
                    error_msg = "Internal server error (500)"
                else:
                    error_msg = f"HTTP {response.status_code}"
            else:
                error_msg = ""
            
            return is_available, response.status_code, error_msg
            
        except requests.exceptions.Timeout:
            return False, 0, "Request timeout"
        except requests.exceptions.ConnectionError:
            return False, 0, "Connection error"
        except requests.exceptions.RequestException as e:
            return False, 0, f"Request failed: {str(e)}"
        except Exception as e:
            return False, 0, f"Unexpected error: {str(e)}"
    
    @classmethod
    def validate_urls_in_text(cls, text: str) -> Tuple[List[str], List[str], str]:
        """
        Validate all URLs found in text and return valid/invalid URLs with updated text.
        
        Args:
            text (str): Text containing URLs to validate
            
        Returns:
            Tuple[List[str], List[str], str]: (valid_urls, invalid_urls, updated_text)
        """
        urls = cls.extract_urls_from_text(text)
        valid_urls = []
        invalid_urls = []
        updated_text = text
        
        for url in urls:
            is_available, status_code, error_msg = cls.check_url_availability(url)
            
            if is_available:
                valid_urls.append(url)
            else:
                invalid_urls.append(url)
                # Mark the invalid URL in the text
                marked_url = f"[INVALID URL: {url} - {error_msg}]"
                updated_text = updated_text.replace(url, marked_url)
                logger.warning(f"Found invalid URL: {url} - {error_msg}")
        
        logger.info(f"URL validation completed: {len(valid_urls)} valid, {len(invalid_urls)} invalid")
        return valid_urls, invalid_urls, updated_text
    
    @classmethod
    def clean_text_from_invalid_urls(cls, text: str) -> Tuple[str, List[str]]:
        """
        Remove invalid URLs from text and return cleaned text with list of removed URLs.
        
        Args:
            text (str): Text containing URLs to clean
            
        Returns:
            Tuple[str, List[str]]: (cleaned_text, removed_urls)
        """
        urls = cls.extract_urls_from_text(text)
        removed_urls = []
        cleaned_text = text
        
        for url in urls:
            is_available, status_code, error_msg = cls.check_url_availability(url)
            
            if not is_available:
                removed_urls.append(url)
                # Remove the invalid URL from text
                cleaned_text = cleaned_text.replace(url, "")
                # Clean up any double spaces or formatting issues
                cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
                logger.info(f"Removed invalid URL: {url} - {error_msg}")
        
        logger.info(f"URL cleanup completed: {len(removed_urls)} URLs removed")
        return cleaned_text.strip(), removed_urls
