"""
Logging Configuration Module
---------------------------
This module provides centralized logging configuration for the DocZense application.
Includes structured logging with different levels and formatters for production and development.
"""

import logging
import logging.handlers
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


class DocZenseLogger:
    """
    Centralized logger configuration for DocZense application.
    
    Provides structured logging with file rotation, console output,
    and different log levels for various components.
    """
    
    _loggers = {}
    _initialized = False
    
    @classmethod
    def setup_logging(
        cls,
        log_level: str = "INFO",
        log_dir: Optional[str] = None,
        max_file_size: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5,
        console_output: bool = True
    ) -> None:
        """
        Setup global logging configuration for the application.
        
        Args:
            log_level (str): Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir (Optional[str]): Directory for log files. If None, uses ./logs
            max_file_size (int): Maximum size of log file before rotation (bytes)
            backup_count (int): Number of backup log files to keep
            console_output (bool): Whether to output logs to console
        """
        if cls._initialized:
            return
            
        # Set log directory
        if log_dir is None:
            log_dir = Path.cwd() / "logs"
        else:
            log_dir = Path(log_dir)
            
        log_dir.mkdir(exist_ok=True)
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(getattr(logging, log_level.upper()))
        
        # Clear existing handlers
        root_logger.handlers.clear()
        
        # Create formatters
        detailed_formatter = logging.Formatter(
            fmt="%(asctime)s | %(name)s | %(levelname)s | %(filename)s:%(lineno)d | %(funcName)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        
        console_formatter = logging.Formatter(
            fmt="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
            datefmt="%H:%M:%S"
        )
        
        # File handler with rotation
        file_handler = logging.handlers.RotatingFileHandler(
            filename=log_dir / f"doczense_{datetime.now().strftime('%Y%m%d')}.log",
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding="utf-8"
        )
        file_handler.setFormatter(detailed_formatter)
        file_handler.setLevel(logging.DEBUG)
        root_logger.addHandler(file_handler)
        
        # Error file handler (separate file for errors)
        error_handler = logging.handlers.RotatingFileHandler(
            filename=log_dir / f"doczense_errors_{datetime.now().strftime('%Y%m%d')}.log",
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding="utf-8"
        )
        error_handler.setFormatter(detailed_formatter)
        error_handler.setLevel(logging.ERROR)
        root_logger.addHandler(error_handler)
        
        # Console handler
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(console_formatter)
            console_handler.setLevel(getattr(logging, log_level.upper()))
            root_logger.addHandler(console_handler)
        
        cls._initialized = True
        
        # Log initialization
        logger = cls.get_logger("DocZenseLogger")
        logger.info(f"Logging initialized - Level: {log_level}, Log Dir: {log_dir}")
    
    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        """
        Get a logger instance for a specific component.
        
        Args:
            name (str): Logger name (typically module or class name)
            
        Returns:
            logging.Logger: Configured logger instance
        """
        if not cls._initialized:
            cls.setup_logging()
            
        if name not in cls._loggers:
            cls._loggers[name] = logging.getLogger(name)
            
        return cls._loggers[name]
    
    @classmethod
    def log_function_call(cls, logger: logging.Logger, func_name: str, args: tuple = (), kwargs: dict = None):
        """
        Log function entry with parameters.
        
        Args:
            logger (logging.Logger): Logger instance
            func_name (str): Function name
            args (tuple): Function positional arguments
            kwargs (dict): Function keyword arguments
        """
        kwargs = kwargs or {}
        args_str = ", ".join([repr(arg) for arg in args])
        kwargs_str = ", ".join([f"{k}={repr(v)}" for k, v in kwargs.items()])
        params = ", ".join(filter(None, [args_str, kwargs_str]))
        
        logger.debug(f"ENTER {func_name}({params})")
    
    @classmethod
    def log_function_exit(cls, logger: logging.Logger, func_name: str, result=None, execution_time: float = None):
        """
        Log function exit with result and execution time.
        
        Args:
            logger (logging.Logger): Logger instance
            func_name (str): Function name
            result: Function return value
            execution_time (float): Execution time in seconds
        """
        msg = f"EXIT {func_name}"
        if execution_time is not None:
            msg += f" (took {execution_time:.4f}s)"
        if result is not None:
            msg += f" -> {repr(result)}"
            
        logger.debug(msg)
    
    @classmethod
    def log_error(cls, logger: logging.Logger, error: Exception, context: str = ""):
        """
        Log error with full context and traceback.
        
        Args:
            logger (logging.Logger): Logger instance
            error (Exception): Exception that occurred
            context (str): Additional context information
        """
        error_msg = f"ERROR: {type(error).__name__}: {str(error)}"
        if context:
            error_msg = f"{context} - {error_msg}"
            
        logger.error(error_msg, exc_info=True)


def timed_function(logger: logging.Logger):
    """
    Decorator to automatically log function entry, exit, and execution time.
    
    Args:
        logger (logging.Logger): Logger instance to use
        
    Returns:
        Function decorator
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            import time
            
            # Log entry
            DocZenseLogger.log_function_call(logger, func.__name__, args, kwargs)
            
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                
                # Log successful exit
                DocZenseLogger.log_function_exit(logger, func.__name__, result, execution_time)
                return result
                
            except Exception as e:
                execution_time = time.time() - start_time
                
                # Log error
                DocZenseLogger.log_error(
                    logger, 
                    e, 
                    f"Function {func.__name__} failed after {execution_time:.4f}s"
                )
                raise
                
        return wrapper
    return decorator


# Initialize logging on module import
DocZenseLogger.setup_logging(
    log_level=os.getenv("DOCZENSE_LOG_LEVEL", "INFO"),
    console_output=os.getenv("DOCZENSE_CONSOLE_LOGGING", "true").lower() == "true"
)
