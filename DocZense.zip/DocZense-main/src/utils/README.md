# URL Utilities Module

This module provides comprehensive URL detection, validation, and management functionality for the DocZense application.

## Features

### 1. URL Detection
- Detects full URLs with protocols (http/https)
- Detects bare domains and converts them to full URLs
- Supports various TLDs (.com, .org, .net, etc.)
- Handles subdomains and paths

### 2. URL Validation
- Checks if URLs are accessible (not 404)
- Handles various HTTP status codes
- Provides detailed error messages
- Configurable timeout settings

### 3. Text Processing
- Validates all URLs in text content
- Marks invalid URLs with error messages
- Cleans text by removing invalid URLs
- Preserves text formatting

## Usage

### URL Extraction
```python
from utils.url_utils import URLUtils

text = "Visit https://example.com and check out github.com"
urls = URLUtils.extract_urls_from_text(text)
# Returns: ['https://example.com', 'https://github.com']
```

### URL Validation
```python
from utils.url_utils import URLUtils
from utils.logger import DocZenseLogger

logger = DocZenseLogger.get_logger("URLValidation")

is_available, status_code, error_msg = URLUtils.check_url_availability("https://example.com")
if is_available:
    logger.info("URL is accessible")
else:
    logger.error(f"URL failed: {error_msg}")
```

### Text Validation and Cleaning
```python
from utils.url_utils import URLUtils

# Validate URLs and mark invalid ones
valid_urls, invalid_urls, marked_text = URLUtils.validate_urls_in_text(text)

# Clean text by removing invalid URLs
cleaned_text, removed_urls = URLUtils.clean_text_from_invalid_urls(text)
```

## Integration

### Document Chatbot
The document chatbot now uses URLUtils for URL extraction from user queries, replacing the previous regex-based approach.

### CRM Chatbot
The CRM chatbot validates URLs in generated responses:
1. Extracts URLs from the response
2. Checks each URL for accessibility
3. If invalid URLs are found, regenerates the response without URLs
4. Uses the LLM API to create URL-free responses

## Error Handling

The module handles various error scenarios:
- Connection timeouts
- DNS resolution failures
- HTTP error status codes (404, 403, 500, etc.)
- Invalid URL formats
- Network connectivity issues

## Performance Considerations

- Uses HEAD requests for URL checking (faster than GET)
- Configurable timeout settings
- Minimal network overhead
- Caches are not implemented (could be added for performance)

## Testing

Run the test script to verify functionality:
```bash
python test_url_utils.py
```

The test covers:
- URL extraction from various text formats
- URL validation with known working/failing URLs
- Text cleaning and URL removal
