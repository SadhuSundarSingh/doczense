"""
OAuth Authentication Manager Module
---------------------------------
This module provides functionality to manage OAuth authentication tokens
for accessing external APIs, including automatic token refresh.
"""

import json
import time
import requests
from datetime import datetime

from utils.logger import DocZenseLogger

# Initialize logger for this module
logger = DocZenseLogger.get_logger("AuthManager")

import json
import requests
import time
from typing import Dict, Any, Optional
from datetime import datetime

class AuthManager:
    """
    Authentication manager for handling OAuth tokens.
    
    This class provides methods to get, cache, and refresh OAuth tokens
    for accessing external APIs securely. Tokens are stored in memory
    rather than in files for improved security.
    
    Attributes:
        _instance (AuthManager): Singleton instance of the AuthManager
        _access_token (str): Current OAuth access token
        _token_expiry (float): Expiration timestamp for the current token
        TOKEN_EXPIRY_SECONDS (int): Token validity period in seconds
    """
    _instance = None
    _access_token: Optional[str] = None
    _token_expiry: float = 0
    TOKEN_EXPIRY_SECONDS: int = 3600  # 1 hour expiry
    
    def __new__(cls):
        """
        Implement singleton pattern for AuthManager.
        
        Returns:
            AuthManager: The singleton instance of AuthManager
        """
        if cls._instance is None:
            cls._instance = super(AuthManager, cls).__new__(cls)
        return cls._instance
    
    @classmethod
    def get_oauth_token(cls) -> str:
        """
        Get a valid OAuth token, refreshing if necessary.
        
        This method checks if a valid token exists in memory,
        and if not, or if it's expired, generates a new one.
        
        Returns:
            str: Valid OAuth access token
        """
        # Check if token needs refresh (expired or missing)
        current_time = time.time()
        if cls._access_token is None or current_time >= cls._token_expiry:
            logger.info(f"Starting access token generation at {datetime.now().isoformat()}")
            
            # API endpoint for token refresh
            url = "https://accounts.zoho.com/oauth/v2/token"

            # Load credentials from file
            try:
                with open("resources/oauth.json", "r") as cred_file:
                    payload = json.load(cred_file)
                logger.debug("OAuth credentials loaded successfully")
            except FileNotFoundError as e:
                logger.error("OAuth credentials file not found", exc_info=True)
                raise FileNotFoundError("OAuth credentials file not found. Please ensure 'resources/oauth.json' exists.") from e
            except json.JSONDecodeError as e:
                logger.error("Invalid OAuth credentials format", exc_info=True)
                raise ValueError("Invalid OAuth credentials format. Please check 'resources/oauth.json'.") from e
            
            # Make the API request
            try:
                logger.debug("Making OAuth token request")
                response = requests.request("POST", url, data=payload)
                response.raise_for_status()  # Raise exception for HTTP errors
                
                # Update token data in memory
                cls._token_expiry = current_time + cls.TOKEN_EXPIRY_SECONDS
                cls._access_token = response.json()["access_token"]
                
                expiry_time = datetime.fromtimestamp(cls._token_expiry).isoformat()
                logger.info(f"Access token generation completed. Valid until {expiry_time}")
                
            except requests.exceptions.RequestException as e:
                logger.error(f"Failed to obtain OAuth token: {str(e)}", exc_info=True)
                raise ConnectionError(f"Failed to obtain OAuth token: {str(e)}") from e
            except (KeyError, ValueError) as e:
                logger.error(f"Invalid response format from OAuth server: {str(e)}", exc_info=True)
                raise ValueError(f"Invalid response format from OAuth server: {str(e)}") from e
        else:
            logger.debug("Using existing valid access token")
            
        return cls._access_token


# Provide a function for backwards compatibility
def get_oauth_token() -> str:
    """
    Get a valid OAuth token using the AuthManager class.
    
    This function is maintained for backwards compatibility with existing code.
    
    Returns:
        str: Valid OAuth access token
        
    Raises:
        FileNotFoundError: If the credentials file is not found
        ValueError: If credentials are invalid or server response is malformed
        ConnectionError: If there's a problem communicating with the OAuth server
    """
    return AuthManager.get_oauth_token()