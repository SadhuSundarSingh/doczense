"""
LLM Inference Module
------------------
This module provides functionality to interact with the LLM API for
generating responses based on context and prompts.
"""

import json
import requests
from typing import List, Dict, Any

from api.auth_manager import get_oauth_token
from utils.logger import DocZenseLogger, timed_function

# Initialize logger for this module
logger = DocZenseLogger.get_logger("LLMInference")

class LLMInference:
    """
    Class for handling interactions with the LLM API.
    
    This class provides methods to format requests and fetch responses
    from the Large Language Model API.
    """
    
    # API endpoint
    API_URL = "https://platformai.zoho.com/internalapi/v2/ai/chat"
    
    # Default model configuration
    DEFAULT_MODEL = "qwen-2.5-32b-instruct-zlabs"
    DEFAULT_VENDOR = "zia"
    
    @staticmethod
    @timed_function(logger)
    def fetch_from_llm(data: List[Dict[str, str]], system_prompt: str) -> str:
        """
        Fetch a response from the LLM API based on provided data and system prompt.
        
        Args:
            data (List[Dict[str, str]]): List of message objects with role and content
            system_prompt (str): System instructions for the model
            
        Returns:
            str: Generated response from the LLM
        """
        logger.info("Starting LLM inference request")
        logger.debug(f"Request payload: {len(data)} messages, system prompt length: {len(system_prompt)}")
        
        try:
            # Get authentication token
            access_token = get_oauth_token()
            
            # Prepare request payload
            payload = {
                "messages": data,
                "context": system_prompt,
                "ai_vendor": LLMInference.DEFAULT_VENDOR,
                "model": LLMInference.DEFAULT_MODEL
            }
            
            # Set request headers
            headers = {
                "portal_id": "ZLabs",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            logger.debug(f"Making API request to {LLMInference.API_URL}")
            # Make API request
            response = requests.request(
                "POST", 
                LLMInference.API_URL, 
                headers=headers, 
                data=json.dumps(payload)
            )
            
            # Check for HTTP errors
            response.raise_for_status()
            
            # Extract and return the result
            result = response.json()["data"]["results"][0]
            logger.info(f"LLM inference completed successfully ({len(result)} characters)")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"LLM API request failed: {str(e)}", exc_info=True)
            raise
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            logger.error(f"Failed to parse LLM API response: {str(e)}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Unexpected error during LLM inference: {str(e)}", exc_info=True)
            raise


# Function for backwards compatibility
@timed_function(logger)
def fetch_from_llm(data: List[Dict[str, str]], system_prompt: str) -> str:
    """
    Fetch a response from the LLM API using the LLMInference class.
    
    This function is maintained for backwards compatibility with existing code.
    
    Args:
        data (List[Dict[str, str]]): List of message objects with role and content
        system_prompt (str): System instructions for the model
        
    Returns:
        str: Generated response from the LLM
    """
    return LLMInference.fetch_from_llm(data, system_prompt)

    