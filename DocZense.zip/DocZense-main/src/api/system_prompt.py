import os
import time
from enum import Enum
from pathlib import Path
from typing import Dict

from utils.logger import DocZenseLogger

# Initialize logger for this module
logger = DocZenseLogger.get_logger("SystemPrompt")

# Cache for loaded prompts (module-level)
_prompt_cache: Dict[str, str] = {}


class SystemPrompt(Enum):
    """
    System prompts loaded from external text files.
    
    This class loads prompts from the resources/prompts/ directory
    to make them easily editable without modifying code.
    """
    
    FINAL_RESPONSE = "final_response.txt"
    QUERY_REWRITE = "query_rewrite.txt" 
    CRM_PROMPT = "crm_prompt.txt"
    CRM_URL_FREE = "crm_url_free.txt"
    
    @property
    def value(self) -> str:
        """
        Load and return the prompt content from the corresponding text file.
        
        Returns:
            str: The prompt content from the text file
        """
        global _prompt_cache
        
        if self._value_ not in _prompt_cache:
            prompt_file_path = Path("resources/prompts") / self._value_
            
            try:
                logger.debug(f"Loading system prompt from {prompt_file_path}")
                load_start_time = time.time()
                
                with open(prompt_file_path, 'r', encoding='utf-8') as f:
                    prompt_content = f.read().strip()
                
                load_end_time = time.time()
                _prompt_cache[self._value_] = prompt_content
                
                logger.info(f"✅ Loaded system prompt '{self.name}' from {prompt_file_path} in {load_end_time - load_start_time:.4f} seconds ({len(prompt_content)} characters)")
                
            except FileNotFoundError:
                logger.error(f"❌ Prompt file not found: {prompt_file_path}")
                raise FileNotFoundError(f"Prompt file not found: {prompt_file_path}")
            except Exception as e:
                logger.error(f"❌ Error loading prompt from {prompt_file_path}: {str(e)}", exc_info=True)
                raise Exception(f"Error loading prompt from {prompt_file_path}: {str(e)}")
        else:
            logger.debug(f"Using cached system prompt '{self.name}'")
        
        return _prompt_cache[self._value_]
    
    @classmethod
    def reload_prompts(cls):
        """
        Clear the prompt cache to force reloading from files.
        Useful for development when prompts are being modified.
        """
        global _prompt_cache
        _prompt_cache.clear()
        logger.info("🔄 System prompt cache cleared - prompts will be reloaded on next access")
    
    @classmethod
    def list_available_prompts(cls) -> Dict[str, str]:
        """
        List all available prompts and their file paths.
        
        Returns:
            Dict[str, str]: Mapping of prompt names to file paths
        """
        prompts = {}
        for prompt in cls:
            prompt_file_path = Path("resources/prompts") / prompt._value_
            prompts[prompt.name] = str(prompt_file_path)
        return prompts
    
    @classmethod
    def validate_prompt_files(cls) -> bool:
        """
        Validate that all prompt files exist and are readable.
        
        Returns:
            bool: True if all files are valid, raises exception otherwise
        """
        validation_start_time = time.time()
        logger.info("🔍 Validating system prompt files...")
        
        missing_files = []
        invalid_files = []
        
        for prompt in cls:
            prompt_file_path = Path("resources/prompts") / prompt._value_
            
            if not prompt_file_path.exists():
                missing_files.append(str(prompt_file_path))
                logger.error(f"❌ Missing prompt file: {prompt_file_path}")
            else:
                try:
                    with open(prompt_file_path, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                        if not content:
                            invalid_files.append(f"{prompt_file_path} (empty)")
                            logger.warning(f"⚠️ Empty prompt file: {prompt_file_path}")
                        else:
                            logger.debug(f"✅ Valid prompt file: {prompt_file_path} ({len(content)} characters)")
                except Exception as e:
                    invalid_files.append(f"{prompt_file_path} ({str(e)})")
                    logger.error(f"❌ Cannot read prompt file {prompt_file_path}: {str(e)}")
        
        validation_end_time = time.time()
        validation_time = validation_end_time - validation_start_time
        
        if missing_files or invalid_files:
            error_msg = "Prompt file validation failed:\n"
            if missing_files:
                error_msg += f"Missing files: {missing_files}\n"
            if invalid_files:
                error_msg += f"Invalid files: {invalid_files}"
            
            logger.error(f"❌ Prompt file validation failed in {validation_time:.4f} seconds")
            raise FileNotFoundError(error_msg)
        
        logger.info(f"✅ All {len(cls)} system prompt files validated successfully in {validation_time:.4f} seconds")
        return True


# Validate prompt files on module import
try:
    SystemPrompt.validate_prompt_files()
except Exception as e:
    logger.warning(f"Prompt file validation failed during import: {str(e)}")
    logger.info("System will attempt to load prompts on-demand")

