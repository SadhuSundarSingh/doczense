"""
DocZense Application
-------------------
Main application module for DocZense, a document analysis and question answering system.
This module serves as the entry point for the Gradio interface with multiple chatbot tabs.
"""

import gradio as gr

from chatbots.crm_chatbot import CRMChatbot
from chatbots.document_chatbot import DocumentChatbot
from utils.logger import DocZenseLogger, timed_function

# Initialize logger for this module
logger = DocZenseLogger.get_logger("DocZenseApp")

# Create singleton instance
logger.info("Initializing DocumentChatbot singleton")
document_chatbot = DocumentChatbot()


# Create singleton instance
logger.info("Initializing CRMChatbot singleton")
crm_chatbot = CRMChatbot()


@timed_function(logger)
def get_document_chatbot():
    """
    Create and configure the document chat chatbot with clear event.
    
    Returns:
        tuple: (chatbot, chat_interface) - The configured chatbot and chat interface
    """
    # Create a custom chatbot that we can attach clear event to
    doc_chatbot = gr.Chatbot(
        label="Document Chat",
        type="messages",
        avatar_images=(None, "resources/assets/doczense.png"),
        show_copy_button=True
    )
    
    # Attach clear event to reset embeddings when chat is cleared
    doc_chatbot.clear(
        fn=document_chatbot.clear_embeddings,
        outputs=[]
    )
    
    doc_chat = gr.ChatInterface(
        document_chatbot.answer,
        type="messages",
        textbox=gr.MultimodalTextbox(file_types=[".pdf"]),
        multimodal=True,
        show_api=False,
        chatbot=doc_chatbot,
        description="Upload any PDF file or enter URLs and ask questions about them!",
        examples=[
            {
                "text": "Summarize the main points of \"How To Read a Paper \"",
                "files": ["resources/how-to-read-a-paper.pdf"]
            },
            {
                "text": "Explain \"Attention Is All You Need\" like a 5-year-old",
                "files": ["resources/attention-is-all-you-need.pdf"]
            },
            "github.com/microsoft/vscode - Tell me about this repository",
            "Compare products of zoho.com & microsoft.com"
        ]
    )
    
    return doc_chatbot, doc_chat


@timed_function(logger)
def get_crm_chatbot():
    """
    Create and configure the CRM assistant chatbot.
    
    Returns:
        tuple: (chatbot, chat_interface) - The configured chatbot and chat interface
    """
    # Create a custom chatbot for CRM
    crm_chatbot_ui = gr.Chatbot(
        label="CRM Assistant",
        type="messages",
        avatar_images=(None, "resources/assets/crm.png"), 
        show_copy_button=True
    )
    
    crm_chat = gr.ChatInterface(
        crm_chatbot.answer,
        type="messages",
        chatbot=crm_chatbot_ui,
        description="Ask anything about Zoho CRM.",
        show_api=False,
        examples=[
            "What are the different stages in the sales pipeline?",
            "How can I set up email automation in Zoho CRM?",
            "What is the difference between leads and contacts?",
            "How do I generate reports in Zoho CRM?",
            "How can I customize fields in Zoho CRM?",
            "What are workflow rules and how do I create them?",
            "How do I integrate Zoho CRM with other applications?",
            "How can I track customer interactions and communication history?"
        ]
    )
    
    return crm_chatbot_ui, crm_chat


if __name__ == "__main__":
    """
    Application entry point.
    
    Creates the Gradio UI with two tabs:
    1. Document chat - Upload PDFs or provide URLs to chat with their content
    2. CRM assistant - Ask questions about Zoho CRM
    """
    logger.info("Starting DocZense application")
    
    try:
        with gr.Blocks(title="DocZense") as demo:
            with gr.Tabs() as tabs:
                with gr.TabItem("Chat with PDF/URLs"):
                    logger.info("Setting up Document Chat tab")
                    doc_chatbot, doc_chat = get_document_chatbot()
                
                with gr.TabItem("Zoho CRM Assistant"):
                    logger.info("Setting up CRM Assistant tab")
                    crm_chatbot, crm_chat = get_crm_chatbot()
        
        # Launch the application server
        logger.info("Launching Gradio server on port 8001")
        demo.launch(
            favicon_path="resources/assets/doczense.png",
            server_port=8001,
            height="100%"
        )
        logger.info("DocZense application started successfully")
        
    except Exception as e:
        logger.error(f"Failed to start DocZense application: {str(e)}", exc_info=True)
        raise
