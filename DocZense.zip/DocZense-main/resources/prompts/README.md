# System Prompts

This directory contains the system prompts used by DocZense's AI components. Each prompt is stored in a separate text file for easy editing and maintenance.

## Available Prompts

### `final_response.txt`
- **Purpose**: Used for generating final responses in the document Q&A system
- **Context**: Applied when answering questions about uploaded PDFs or web content
- **Key Features**: 
  - Encourages bullet points and emojis for readability
  - Allows combining context with general knowledge
  - Handles unknown information gracefully

### `query_rewrite.txt`
- **Purpose**: Used for improving user queries before semantic search
- **Context**: Applied to both document and CRM queries to enhance retrieval accuracy
- **Key Features**:
  - Preserves original intent while improving clarity
  - Makes queries more specific and informative
  - Optimizes for search/retrieval systems

### `crm_prompt.txt`
- **Purpose**: Used for Zoho CRM-specific question answering
- **Context**: Applied when generating responses about CRM functionality
- **Key Features**:
  - Strictly adheres to official documentation
  - Returns "NOT FOUND" for unknown information
  - Formats responses with bullet points and emojis
  - Avoids general knowledge or assumptions

## Usage

The prompts are automatically loaded by the `SystemPrompt` enum class in `src/api/system_prompt.py`. The system:

1. **Loads on demand**: Prompts are cached when first accessed
2. **Validates files**: Checks for existence and readability on startup
3. **Provides logging**: Tracks when prompts are loaded and cached
4. **Supports reloading**: Can clear cache to reload modified prompts

## Editing Prompts

To modify a prompt:

1. Edit the corresponding `.txt` file directly
2. Save the file
3. Restart the application OR call `SystemPrompt.reload_prompts()` in development

## Best Practices

- **Keep prompts focused**: Each prompt should have a single, clear purpose
- **Use clear language**: Write prompts that are easy for the AI to understand
- **Test changes**: Validate that prompt changes improve response quality
- **Version control**: Track prompt changes through git for rollback capability
- **Document changes**: Note significant prompt modifications in commit messages

## Technical Details

- **Encoding**: All files use UTF-8 encoding
- **File format**: Plain text (.txt) files
- **Caching**: Prompts are cached in memory after first load
- **Error handling**: Missing or invalid files trigger clear error messages
- **Performance**: File loading is tracked with timing logs

## Troubleshooting

If you encounter issues:

1. **Check file paths**: Ensure files are in `resources/prompts/` directory
2. **Verify permissions**: Make sure files are readable
3. **Check encoding**: Ensure files are saved as UTF-8
4. **Review logs**: Check application logs for specific error messages
5. **Validate syntax**: Ensure no special characters cause parsing issues
